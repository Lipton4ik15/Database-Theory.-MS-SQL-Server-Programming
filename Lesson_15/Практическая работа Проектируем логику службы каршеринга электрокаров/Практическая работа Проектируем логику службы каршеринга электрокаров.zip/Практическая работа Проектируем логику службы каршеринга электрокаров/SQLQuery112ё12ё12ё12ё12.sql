
--IF NOT EXISTS (SELECT * FROM  sys.databases WHERE NAME = 'Pestov_Karshering')
--	CREATE DATABASE Pestov_Karshering
--GO
--USE Pestov_Karshering;
--GO




--IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Cars')
--CREATE TABLE dbo.Cars (

--CarId INT IDENTITY(1,1) PRIMARY KEY,
--VinNumber NVARCHAR(50) NOT NULL UNIQUE,
--Model NVARCHAR(50) NOT NULL,
--Year INT NOT NULL,
--MaxRangeKm INT NOT NULL,-- запас хода на полном заряде
--BatteryLevel INT NOT NULL DEFAULT 100,--0–100%
--CurrentMileage DECIMAL(10,2) NOT NULL,-- пробег в км
--Status NVARCHAR(20) NOT NULL DEFAULT'Available'
--CHECK(Status IN ('Available','Rented','Maintenance','Charging','Accident')),
--LastServiceDate DATE NULL,
--NextServiceKm DECIMAL(8,2) NOT NULL
--);



--IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Drivers')
--CREATE TABLE dbo.Drivers (
--DriverId INT IDENTITY(1,1) PRIMARY KEY,
--FullName NVARCHAR(100) NOT NULL,
--LicenseNumber NVARCHAR(20) NOT NULL UNIQUE,
--LicenseExpiry DATE NOT NULL,
--TotalRents INT NOT NULL DEFAULT 0,
--TotalDistance DECIMAL(10,2) NOT NULL DEFAULT 0,
--AccidentCount INT NOT NULL DEFAULT 0,
--IsActive BIT NOT NULL DEFAULT 1
--);

--IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Customers')
--CREATE TABLE dbo.Customers (
--CustomerId INT IDENTITY(1,1) PRIMARY KEY,
--FullName NVARCHAR(100) NOT NULL,
--Phone NVARCHAR(20) NOT NULL,
--Email NVARCHAR(100) NULL,
--City NVARCHAR(50) NOT NULL
--);



--IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Rentals')
--CREATE TABLE dbo.Rentals (
--RentalId INT IDENTITY(1,1) PRIMARY KEY,
--CustomerId INT NOT NULL,
--CarId INT NOT NULL,
--DriverId INT NOT NULL,
--StartAt DATETIME NOT NULL,
--EndAt DATETIME NULL,
--StartOdometer DECIMAL(10,2) NOT NULL,
--EndOdometer DECIMAL(10,2) NULL,
--DistanceCovered DECIMAL(10,2) NULL, -- км
--BaseCost DECIMAL(10,2) NOT NULL,--базовая стоимость
--ExtraCost DECIMAL(10,2) NOT NULL DEFAULT 0,--доп. штрафы/надбавки
--TotalCost DECIMAL(10,2) NOT NULL DEFAULT 0,
--Status NVARCHAR(20) NOT NULL DEFAULT'Active'
--CHECK(Status IN ('Active','Completed','Cancelled','Disputed')),
--CreatedAt DATETIME NOT NULL DEFAULT GETDATE(),
--CONSTRAINT FK_Rentals_Customer FOREIGN KEY (CustomerId) REFERENCES dbo.Customers(CustomerId),
--CONSTRAINT FK_Rentals_Car FOREIGN KEY (CarId) REFERENCES dbo.Cars(CarId),
--CONSTRAINT FK_Rentals_Driver FOREIGN KEY (DriverId) REFERENCES dbo.Drivers(DriverId)
--);




--IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'ChargingLogs')
--CREATE TABLE dbo.ChargingLogs (
--LogId INT IDENTITY(1,1) PRIMARY KEY,
--CarId INT NOT NULL,
--ChargingStart DATETIME NOT NULL,
--ChargingEnd DATETIME NULL,
--EnergyConsumedKwh DECIMAL(6,2) NULL,-- сколько кВт·ч «залито»-- уровень до зарядки
--ChargeFrom INT NULL,-- уровень после заряд
--ChargeTo INT NULL,
--Location NVARCHAR(100) NULL,
--CONSTRAINT FK_CL_Car FOREIGN KEY(CarId) REFERENCES dbo.Cars(CarId)
--);



--IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'RentalStatusLog')
--CREATE TABLE dbo.RentalStatusLog (
--LogId INT IDENTITY(1,1) PRIMARY KEY,
--RentalId INT NOT NULL,
--OldStatus NVARCHAR(20) NULL,
--NewStatus NVARCHAR(20) NOT NULL,
--ChangedAt DATETIME NOT NULL DEFAULT GETDATE(),
--ChangedBy NVARCHAR(100) NOT NULL DEFAULT SYSTEM_USER,
--CONSTRAINT FK_RSL_Rental FOREIGN KEY (RentalId) REFERENCES dbo.Rentals(RentalId)
--);

--Тестовые данные


--INSERT dbo.Cars (VinNumber, Model, Year, MaxRangeKm, BatteryLevel, CurrentMileage, Status,
--LastServiceDate, NextServiceKm) VALUES
--(N'WBA12345678901234', N'BMW i3', 2021, 260, 82, 15200.5, N'Available', '2025-08-01', 16000),
--(N'WBA54321987654321', N'BMW i3', 2022, 260, 45, 9800.2, N'Available', '2025-07-10', 10500),
--(N'VIN-TESLA-001', N'Tesla Model 3', 2023, 528, 95, 3200.0, N'Available', '2025-09-01', 5000),
--(N'VIN-TESLA-002', N'Tesla Model 3', 2020, 425, 12, 41200.7, N'Charging', '2025-08-15', 42000),
--(N'VIN-NISSAN-LEAF', N'Nissan Leaf', 2019, 240, 70, 58000.3, N'Maintenance', '2025-06-01', 60000);


--INSERT dbo.Drivers (FullName, LicenseNumber, LicenseExpiry, TotalRents, TotalDistance,
--AccidentCount, IsActive) VALUES
--(N'Игорь Петров', N'DL-2024-101', '2027-12-31', 35, 1200.5, 0, 1),
--(N'Ольга Смирнова', N'DL-2024-102', '2026-11-20', 52, 2100.0, 1, 1),
--(N'Дмитрий Волков', N'DL-2023-103', '2025-10-10', 8, 320.2, 2, 1),
--(N'Анна Кузнецова', N'DL-2025-104', '2028-03-05', 12, 450.0, 0, 1);


--INSERT dbo.Customers (FullName, Phone, Email, City) VALUES
--(N'Сергей Иванов', N'+7-900-111-22-33', N'sergey@example.com', N'Москва'),
--(N'Елена Морозова', N'+7-900-222-33-44', N'elena@example.com', N'Москва'),
--(N'Максим Соколов', N'+7-900-333-44-55', NULL, N'Санкт-Петербург'),
--(N'Ирина Лебедева', N'+7-900-444-55-66', N'irina@example.com', N'Казань');


--INSERT dbo.Rentals (CustomerId, CarId, DriverId, StartAt, EndAt, StartOdometer, EndOdometer,
--DistanceCovered, BaseCost, ExtraCost, TotalCost, Status, CreatedAt) VALUES
--(1, 1, 1, '2025-09-17 09:00', '2025-09-17 14:30', 15200.5, 15245.2, 44.7, 2800.00, 0, NULL, 'Completed','2025-09-17 08:55'),
--(2, 3, 2, '2025-09-17 11:00', '2025-09-17 13:15', 3200.0, 3285.5, 85.5, 4200.00, 0, NULL, 'Completed','2025-09-17 10:55'),
--(3, 2, 3, '2025-09-18 08:00', NULL,9800.2, NULL, NULL,1800.00, 0, NULL, 'Active','2025-09-18 07:55'),
--(4, 1, 4, '2025-09-18 10:30', NULL,15245.2, NULL, NULL, 2500.00, 0, NULL, 'Active','2025-09-18 10:25');






--INSERT dbo.ChargingLogs (CarId, ChargingStart, ChargingEnd, EnergyConsumedKwh, ChargeFrom,
--ChargeTo, Location) VALUES
--(2, '2025-09-17 20:00', '2025-09-18 00:30', 32.5, 45, 98, N'Зарядная станция ВДНХ'),
--(4, '2025-09-18 09:00', NULL, NULL, 12, NULL, N'Подземная парковка ТЦ');
--GO





-- ТРЕБОВАНИЕ 1: Автоматический журнал статусов аренды (Триггер)
--CREATE OR ALTER TRIGGER trg_RentalStatusLog
--ON dbo.Rentals
--AFTER UPDATE
--AS
--BEGIN
--    SET NOCOUNT ON;
--    IF UPDATE(Status)
--    BEGIN
--        INSERT INTO dbo.RentalStatusLog (RentalId, OldStatus, NewStatus, ChangedAt, ChangedBy)
--        SELECT i.RentalId, d.Status, i.Status, GETDATE(), SYSTEM_USER
--        FROM inserted i
--        INNER JOIN deleted d ON i.RentalId = d.RentalId
--        WHERE i.Status <> d.Status;
--    END
--END;
--GO

---- ТЕСТ 1 — ПОЛОЖИТЕЛЬНЫЙ: меняем статус, запись появляется
--UPDATE dbo.Rentals SET Status = 'Completed' WHERE RentalId = 3;
--SELECT RentalId, OldStatus, NewStatus FROM dbo.RentalStatusLog WHERE RentalId = 3 ORDER BY LogId DESC;
---- Ожидание: OldStatus = Active, NewStatus = Completed

---- ТЕСТ 1 — ОТРИЦАТЕЛЬНЫЙ: обновляем без смены статуса, записи быть не должно
--DECLARE @Before1 INT, @After1 INT;
--SELECT @Before1 = COUNT(*) FROM dbo.RentalStatusLog WHERE RentalId = 1;
--UPDATE dbo.Rentals SET ExtraCost = 500 WHERE RentalId = 1;
--SELECT @After1 = COUNT(*) FROM dbo.RentalStatusLog WHERE RentalId = 1;
--IF @After1 = @Before1
--    PRINT 'ОК: новых записей нет (статус не менялся)';
--ELSE
--    PRINT 'ОШИБКА: триггер сработал без изменения статуса!';
--GO


-- ТРЕБОВАНИЕ 2: Расчёт примерного запаса хода (Функция)
--CREATE OR ALTER FUNCTION dbo.fn_EstimatedRange (@CarId INT)
--RETURNS DECIMAL(10, 2)
--AS
--BEGIN
--    RETURN ISNULL((SELECT CAST(MaxRangeKm * (CAST(BatteryLevel AS DECIMAL(10,2)) / 100.0) AS DECIMAL(10,2))
--                   FROM dbo.Cars WHERE CarId = @CarId), 0);
--END;
--GO

---- ТЕСТ 2 — ПОЛОЖИТЕЛЬНЫЙ: запас хода для всех авто
--SELECT CarId, Model, BatteryLevel, dbo.fn_EstimatedRange(CarId) AS RangeKm FROM dbo.Cars;
---- Ожидание: авто 1 = 213.20, авто 2 = 117.00, авто 3 = 501.60

---- ТЕСТ 2 — ОТРИЦАТЕЛЬНЫЙ: несуществующий CarId
--SELECT dbo.fn_EstimatedRange(999) AS RangeKm;
---- Ожидание: 0.00 (не падает)
--GO



-- ТРЕБОВАНИЕ 3: Оформление аренды авто (Процедура)
------





---- ТРЕБОВАНИЕ 4: Фиксация завершения аренды (Процедура)
--------






---- ТРЕБОВАНИЕ 5: Авто-перевод в зарядку при низком заряде (Триггер)
--CREATE OR ALTER TRIGGER trg_LowBatteryAutoCharge
--ON dbo.Cars
--AFTER UPDATE
--AS
--BEGIN
--    SET NOCOUNT ON;
--    IF UPDATE(BatteryLevel)
--    BEGIN
--        UPDATE c SET c.Status = 'Charging'
--        FROM dbo.Cars c
--        INNER JOIN inserted i ON c.CarId = i.CarId
--        WHERE i.BatteryLevel < 20
--          AND i.Status NOT IN ('Maintenance', 'Accident')
--          AND c.Status NOT IN ('Maintenance', 'Accident');
--    END
--END;
--GO

---- ТЕСТ 5 — ПОЛОЖИТЕЛЬНЫЙ: заряд падает ниже 20% → авто в Charging
--UPDATE dbo.Cars SET BatteryLevel = 15 WHERE CarId = 2;
--SELECT CarId, Status, BatteryLevel FROM dbo.Cars WHERE CarId = 2;
---- Ожидание: Status = Charging, BatteryLevel = 15

---- ТЕСТ 5 — ОТРИЦАТЕЛЬНЫЙ: заряд 50% → авто остаётся Available
--UPDATE dbo.Cars SET BatteryLevel = 50, Status = 'Available' WHERE CarId = 1;
--SELECT CarId, Status, BatteryLevel FROM dbo.Cars WHERE CarId = 1;
---- Ожидание: Status = Available (не Charging)
--GO


---- ТРЕБОВАНИЕ 6: Рейтинг надёжности водителя (Функция)
--CREATE OR ALTER FUNCTION dbo.fn_DriverReliability (@DriverId INT)
--RETURNS DECIMAL(5, 2)
--AS
--BEGIN
--    DECLARE @TotalRents INT, @AccidentCount INT;
--    SELECT @TotalRents = TotalRents, @AccidentCount = AccidentCount
--    FROM dbo.Drivers WHERE DriverId = @DriverId;

--    IF @TotalRents IS NULL OR @TotalRents = 0 RETURN 0;

--    RETURN CAST((CAST(@TotalRents - @AccidentCount AS DECIMAL(10,2)) / CAST(@TotalRents AS DECIMAL(10,2))) * 100 AS DECIMAL(5,2));
--END;
--GO

---- ТЕСТ 6 — ПОЛОЖИТЕЛЬНЫЙ: рейтинг для всех водителей
--SELECT DriverId, FullName, dbo.fn_DriverReliability(DriverId) AS Reliability FROM dbo.Drivers WHERE DriverId <= 4;
---- Ожидание: водитель 1 = 100.00, водитель 2 = 98.08, водитель 3 = 75.00, водитель 4 = 100.00

---- ТЕСТ 6 — ОТРИЦАТЕЛЬНЫЙ: несуществующий водитель
--SELECT dbo.fn_DriverReliability(999) AS Reliability;
---- Ожидание: 0.00 (не падает)
--GO






-- ТРЕБОВАНИЕ 7: Фиксация зарядки и восстановление заряда (Процедура)

CREATE OR ALTER PROCEDURE dbo.usp_CompleteCharging
    @LogId INT,
    @ChargingEnd DATETIME,
    @ChargeTo INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @CarId INT;
    DECLARE @ChargeFrom INT;
    DECLARE @Energy DECIMAL(6,2);
    DECLARE @ErrMsg NVARCHAR(255);

    -- Получаем данные из журнала зарядки
    SELECT @CarId = CarId, @ChargeFrom = ChargeFrom
    FROM dbo.ChargingLogs
    WHERE LogId = @LogId;

    -- Проверка: запись найдена
    IF @CarId IS NULL
    BEGIN
        RAISERROR('Запись о зарядке с LogId = %d не найдена.', 16, 1, @LogId);
        RETURN;
    END

    -- Проверка: ChargeFrom указан
    IF @ChargeFrom IS NULL
    BEGIN
        RAISERROR('ChargeFrom не указан для LogId = %d.', 16, 1, @LogId);
        RETURN;
    END

    -- Проверка: заряд не уменьшается
    IF @ChargeTo < @ChargeFrom
    BEGIN
        SET @ErrMsg = 'ChargeTo (' + CAST(@ChargeTo AS NVARCHAR(10)) + ') меньше ChargeFrom (' + CAST(@ChargeFrom AS NVARCHAR(10)) + ').';
        RAISERROR('%s', 16, 1, @ErrMsg);
        RETURN;
    END

    -- Считаем потреблённую энергию
    SET @Energy = CAST(@ChargeTo - @ChargeFrom AS DECIMAL(6,2));

    -- Атомарная транзакция
    BEGIN TRY
        BEGIN TRANSACTION;

        -- Обновляем журнал зарядки
        UPDATE dbo.ChargingLogs
        SET ChargingEnd = @ChargingEnd,
            ChargeTo = @ChargeTo,
            EnergyConsumedKwh = @Energy
        WHERE LogId = @LogId;

        -- Обновляем авто: уровень батареи и статус
        UPDATE dbo.Cars
        SET BatteryLevel = @ChargeTo,
            Status = CASE
                WHEN @ChargeTo >= 20 THEN 'Available'
                ELSE Status
            END
        WHERE CarId = @CarId;

        COMMIT TRANSACTION;

        -- Возвращаем результат
        SELECT @LogId AS LogId,
               @CarId AS CarId,
               @ChargeFrom AS ChargeFrom,
               @ChargeTo AS ChargeTo,
               @Energy AS EnergyKwh;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION;

        DECLARE @CatchErrMsg NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR('%s', 16, 1, @CatchErrMsg);
    END CATCH;
END;
GO



---- ТЕСТ 7 — ОТРИЦАТЕЛЬНЫЙ: ChargeTo меньше ChargeFrom
--BEGIN TRY
--    -- Сначала сохраняем дату в переменную (так работает всегда)
--    DECLARE @TestEndTime DATETIME = CONVERT(DATETIME, '2025-09-18T15:00:00', 126);

--    EXEC dbo.usp_CompleteCharging
--        @LogId = 2,
--        @ChargingEnd = @TestEndTime,      -- передаём переменную, не функцию!
--        @ChargeTo = 5;                    -- меньше, чем ChargeFrom (12)

--    PRINT 'ОШИБКА: процедура не должна была выполниться!';
--END TRY
--BEGIN CATCH
--    PRINT 'Ожидаемая ошибка: ' + ERROR_MESSAGE();
--END CATCH;
--GO


---- ТЕСТ 7.1 — ПОЛОЖИТЕЛЬНЫЙ: корректная зарядка
--BEGIN TRY
--    -- Сначала сохраняем дату в переменную — так синтаксис всегда правильный
--    DECLARE @TestEndTime DATETIME = CONVERT(DATETIME, '2025-09-18T14:00:00', 126);

--    EXEC dbo.usp_CompleteCharging
--        @LogId = 2,
--        @ChargingEnd = @TestEndTime,
--        @ChargeTo = 90;

--    PRINT 'Тест 7.1 (положительный): ОК';

--    -- Проверка журнала зарядки
--    SELECT LogId, EnergyConsumedKwh, ChargeFrom, ChargeTo
--    FROM dbo.ChargingLogs
--    WHERE LogId = 2;

--    -- Проверка авто
--    SELECT CarId, BatteryLevel, Status
--    FROM dbo.Cars
--    WHERE CarId = 4;
--END TRY
--BEGIN CATCH
--    PRINT 'Ошибка в тесте 7.1: ' + ERROR_MESSAGE();
--END CATCH;
--GO










---- ТРЕБОВАНИЕ 8: Защита от аренды неисправного авто (Триггер)
--CREATE OR ALTER TRIGGER trg_PreventUnavailableCarRent
--ON dbo.Rentals
--AFTER INSERT, UPDATE
--AS
--BEGIN
--    SET NOCOUNT ON;
--    IF UPDATE(CarId)
--    BEGIN
--        IF EXISTS (
--            SELECT 1 FROM inserted i
--            INNER JOIN dbo.Cars c ON i.CarId = c.CarId
--            WHERE c.Status IN ('Maintenance', 'Accident', 'Charging')
--        )
--        BEGIN
--            DECLARE @BadCarId INT, @BadStatus NVARCHAR(20);
--            SELECT TOP 1 @BadCarId = i.CarId, @BadStatus = c.Status
--            FROM inserted i INNER JOIN dbo.Cars c ON i.CarId = c.CarId
--            WHERE c.Status IN ('Maintenance', 'Accident', 'Charging');

--            RAISERROR('ОПЕРАЦИЯ ОТКЛОНЕНА: автомобиль CarId = %d в статусе "%s" — нельзя назначить на аренду.', 16, 1, @BadCarId, @BadStatus);
--            ROLLBACK TRANSACTION;
--        END
--    END
--END;
--GO

---- ТЕСТ 8 — ПОЛОЖИТЕЛЬНЫЙ: вставка аренды с доступным авто 1
--INSERT INTO dbo.Rentals (CustomerId, CarId, DriverId, StartAt, StartOdometer, BaseCost, Status)
--VALUES (2, 1, 2, GETDATE(), 15245.2, 1800.00, 'Active');
--PRINT 'ОК: аренда доступного авто прошла';

---- ТЕСТ 8 — ОТРИЦАТЕЛЬНЫЙ: прямой UPDATE — назначаем авто 5 (Maintenance)
--BEGIN TRY
--    UPDATE dbo.Rentals SET CarId = 5 WHERE RentalId = 4;
--    PRINT 'ОШИБКА: UPDATE прошёл!';
--END TRY
--BEGIN CATCH
--    PRINT 'ОЖИДАЕМАЯ ОШИБКА: ' + ERROR_MESSAGE();
--END CATCH
--GO

